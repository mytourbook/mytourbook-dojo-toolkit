define([
	'./Selection'
], function (Selection) {
	return Selection;
});
