define({
	popupTriggerLabel: 'Pokaži ali skrij stolpce',
	popupLabel: 'Pokaži ali skrij stolpce'
});
