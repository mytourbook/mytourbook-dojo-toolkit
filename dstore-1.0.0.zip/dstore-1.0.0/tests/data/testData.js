define({
	identifier: 'id',
	items: [
		{id: 1, name: 'one', prime: false, mappedTo: 'E'},
		{id: 2, name: 'two', even: true, prime: true, mappedTo: 'D'},
		{id: 3, name: 'three', prime: true, mappedTo: 'C'},
		{id: 4, name: 'four', even: true, prime: false, mappedTo: null},
		{id: 5, name: 'five', prime: true, mappedTo: 'A'}
	]
});
