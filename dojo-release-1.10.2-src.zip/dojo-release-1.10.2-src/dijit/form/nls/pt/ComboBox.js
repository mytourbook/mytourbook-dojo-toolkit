define(
({
		previousMessage: "Opções anteriores",
		nextMessage: "Mais opções"
})
);
